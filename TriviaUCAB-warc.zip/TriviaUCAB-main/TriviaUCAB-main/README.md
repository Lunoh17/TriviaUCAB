# TriviaUCAB
Repositorio del proyecto de programación orientada a objetos, "Trivia UCAB"
